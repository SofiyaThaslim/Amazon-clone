import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
}

export default function Login() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState({})
  const [success, setSuccess] = useState(false)

  function handleSubmit(e) {
    e.preventDefault()
    const nextErrors = {}

    if (!email) nextErrors.email = 'Enter your email to continue.'
    else if (!validEmail(email)) nextErrors.email = 'That email doesn\u2019t look right.'

    if (!password) nextErrors.password = 'Enter your password.'
    else if (password.length < 6) nextErrors.password = 'Use at least 6 characters.'

    setErrors(nextErrors)

    if (Object.keys(nextErrors).length === 0) {
      setSuccess(true)
      setTimeout(() => navigate('/'), 1200)
    }
  }

  return (
    <div className="login-shell fade-in">
      <div className="login-visual">
        <span className="brand">Velvet<em style={{ color: '#F8BBD0', fontStyle: 'normal' }}>Market</em></span>
        <p className="login-quote">
          "Every order tells us what to build next."
          <span>DEMO ACCOUNT — no real data is stored</span>
        </p>
      </div>

      <div className="login-form-side">
        <div className="login-card">
          <h1>Welcome back</h1>
          <p>Sign in to continue to Velvet Market.</p>

          {success && <div className="login-success">Signed in — taking you to the store…</div>}

          <form onSubmit={handleSubmit} noValidate>
            <div className="field">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                type="email"
                className={errors.email ? 'invalid' : ''}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
              />
              {errors.email && <div className="field-error">{errors.email}</div>}
            </div>

            <div className="field">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                className={errors.password ? 'invalid' : ''}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
              />
              {errors.password && <div className="field-error">{errors.password}</div>}
            </div>

            <button type="submit" className="login-submit">Sign in</button>

            <div className="login-meta">
              <Link to="/">Continue as guest</Link>
              <span>New here? Create account</span>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
