import { useEffect, useMemo, useState } from 'react'
import Navbar from '../components/Navbar.jsx'
import ProductCard from '../components/ProductCard.jsx'

const API_URL = 'https://fakestoreapi.com/products'

export default function Home() {
  const [products, setProducts] = useState([])
  const [status, setStatus] = useState('loading') // loading | ready | error
  const [category, setCategory] = useState(null)
  const [query, setQuery] = useState('')
  const [cartCount, setCartCount] = useState(0)

  useEffect(() => {
    let ignore = false
    setStatus('loading')

    fetch(API_URL)
      .then((res) => {
        if (!res.ok) throw new Error('Network response was not ok')
        return res.json()
      })
      .then((data) => {
        if (!ignore) {
          setProducts(data)
          setStatus('ready')
        }
      })
      .catch(() => {
        if (!ignore) setStatus('error')
      })

    return () => { ignore = true }
  }, [])

  const filtered = useMemo(() => {
    return products
      .filter((p) => (category ? p.category === category : true))
      .filter((p) => (query ? p.title.toLowerCase().includes(query.toLowerCase()) : true))
  }, [products, category, query])

  return (
    <>
      <Navbar
        cartCount={cartCount}
        activeCategory={category}
        onSelectCategory={setCategory}
        onSearch={setQuery}
      />

      <section className="hero">
        <div className="hero-inner">
          <div>
            <h1>Everyday objects, <em>chosen</em> with care.</h1>
            <p>
              A small marketplace built to practice real API integration —
              every product below is pulled live from FakeStoreAPI, not hardcoded.
            </p>
            <div className="hero-stats">
              <div><strong>{products.length || '—'}</strong><span>Live products</span></div>
              <div><strong>4</strong><span>Categories</span></div>
              <div><strong>React</strong><span>+ Router</span></div>
            </div>
          </div>
          <div className="hero-visual">
            <span className="hero-badge b1">GET /products</span>
            <span className="hero-badge b2">fetch()</span>
            <span className="hero-badge b3">200 OK</span>
          </div>
        </div>
      </section>

      <main className="container">
        <div className="section-label">
          <h2>{category ? category : 'All products'}</h2>
          <span>{filtered.length} items</span>
        </div>

        {status === 'loading' && <p className="state-msg">Loading products from the API…</p>}
        {status === 'error' && (
          <p className="state-msg">Couldn't reach the product API right now. Please refresh.</p>
        )}
        {status === 'ready' && filtered.length === 0 && (
          <p className="state-msg">No products match your search.</p>
        )}

        {status === 'ready' && filtered.length > 0 && (
          <div className="product-grid">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} onAdd={() => setCartCount((c) => c + 1)} />
            ))}
          </div>
        )}
      </main>

      <footer className="footer">
        Built by <strong>Sofiya Thaslim</strong> · React + React Router + FakeStoreAPI
      </footer>
    </>
  )
}
