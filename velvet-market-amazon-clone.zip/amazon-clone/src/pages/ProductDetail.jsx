import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import Navbar from '../components/Navbar.jsx'

export default function ProductDetail() {
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [status, setStatus] = useState('loading')

  useEffect(() => {
    setStatus('loading')
    fetch(`https://fakestoreapi.com/products/${id}`)
      .then((res) => res.json())
      .then((data) => {
        setProduct(data)
        setStatus('ready')
      })
      .catch(() => setStatus('error'))
  }, [id])

  return (
    <>
      <Navbar cartCount={0} />
      <main className="container">
        <Link to="/" className="back-link">&larr; Back to all products</Link>

        {status === 'loading' && <p className="state-msg">Loading product…</p>}
        {status === 'error' && <p className="state-msg">Couldn't load this product.</p>}

        {status === 'ready' && product && (
          <div className="detail-wrap fade-in">
            <div className="detail-image">
              <img src={product.image} alt={product.title} />
            </div>
            <div>
              <div className="detail-cat">{product.category}</div>
              <h1 className="detail-title">{product.title}</h1>
              <div className="detail-price">${product.price.toFixed(2)}</div>
              <p className="detail-desc">{product.description}</p>
              <span className="product-rating">
                ★ {product.rating?.rate ?? '—'} · {product.rating?.count ?? 0} reviews
              </span>
              <div style={{ marginTop: 22 }}>
                <button className="add-btn" style={{ padding: '12px 22px', fontSize: '0.85rem' }}>
                  Add to cart
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
      <footer className="footer">
        Built by <strong>Sofiya Thaslim</strong> · React + React Router + FakeStoreAPI
      </footer>
    </>
  )
}
