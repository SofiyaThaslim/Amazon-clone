import { Link } from 'react-router-dom'

export default function ProductCard({ product, onAdd }) {
  return (
    <div className="product-card fade-in">
      <Link to={`/product/${product.id}`} className="product-thumb">
        <img src={product.image} alt={product.title} loading="lazy" />
      </Link>
      <div className="product-body">
        <span className="product-cat">{product.category}</span>
        <Link to={`/product/${product.id}`} className="product-title">
          {product.title}
        </Link>
        <span className="product-rating">
          ★ {product.rating?.rate ?? '—'} · {product.rating?.count ?? 0} reviews
        </span>
        <div className="price-tag">
          <span className="amount">${product.price.toFixed(2)}</span>
          <button className="add-btn" onClick={() => onAdd && onAdd(product)}>
            Add to cart
          </button>
        </div>
      </div>
    </div>
  )
}
