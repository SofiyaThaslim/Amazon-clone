import { Link, useNavigate } from 'react-router-dom'

const CATEGORIES = [
  "electronics",
  "jewelery",
  "men's clothing",
  "women's clothing",
]

export default function Navbar({ cartCount = 0, activeCategory, onSelectCategory, onSearch }) {
  const navigate = useNavigate()

  function handleSubmit(e) {
    e.preventDefault()
    const value = e.target.elements.q.value.trim()
    if (onSearch) onSearch(value)
  }

  return (
    <>
      <header className="navbar">
        <div className="navbar-inner">
          <Link to="/" className="brand">Velvet<em>Market</em></Link>

          <form className="search-form" onSubmit={handleSubmit}>
            <input name="q" type="text" placeholder="Search curated goods…" aria-label="Search products" />
            <button type="submit">Search</button>
          </form>

          <nav className="nav-links">
            <button className="linklike" onClick={() => navigate('/login')}>
              Hello, sign in
              <small>Account</small>
            </button>
            <Link to="/">
              Cart<span className="cart-count">{cartCount}</span>
              <small>&nbsp;</small>
            </Link>
          </nav>
        </div>
      </header>

      <div className="category-strip">
        <div className="container">
          <button
            className={!activeCategory ? 'active' : ''}
            onClick={() => onSelectCategory && onSelectCategory(null)}
          >
            All products
          </button>
          {CATEGORIES.map((c) => (
            <button
              key={c}
              className={activeCategory === c ? 'active' : ''}
              onClick={() => onSelectCategory && onSelectCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
    </>
  )
}
